<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    $cod_pro = $_POST['cod_pro'];
    
    // PRUEBAS
    //$cod_pro = 2;
     $datos = array();
    $stmt = $base_de_datos->prepare( "SELECT KEY_UNIMED AS COD_UNIDAD , KEY_PREART as COD_PRO , CANTID_TIPCOM AS CAPACIDAD  FROM TIPO_COMERCIALIZACION WHERE KEY_PREART='$cod_pro'");
     $stmt->setFetchMode(PDO::FETCH_ASSOC);
        // Ejecutamos
        $stmt->execute();
         // Mostramos los resultados
        while ($row = $stmt->fetch()){
            $datos[] = $row;
        }
      echo json_encode(array("Comercializacion" => $datos));
    //echo json_encode($datos);
?>
