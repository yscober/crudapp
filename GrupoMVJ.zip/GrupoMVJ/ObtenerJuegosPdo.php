<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    $cod_usuario = $_POST['cod_usuario'];
    
    // PRUEBAS
    //$cod_usuario = 6522;
    
    $stmt = $base_de_datos->prepare("select V.KEY_VEN as COD_VEN,convert(varchar(10),v.FECHA_VEN,103) + ' '+ case when v.tipo_cp = 5 then 'FA' when v.TIPO_CP = 6 then 'BO' else 'OT' end +'/' + convert(varchar(4),v.SERIE )+'-'+ CONVERT(varchar(8),v.NUMERO) as NOMBRE_CLIENTE  ,c.MONTO_CPC  as TOTAL from VENTAS  v inner join CUENTAS_POR_COBRAR c on c.KEY_VEN = v.KEY_VEN  where v.KEY_CLI  = '$cod_usuario'and MONTO_CPC > 0");
             $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $datos[] = $row;
                        }
   
    echo json_encode(array("Pedidos" => $datos));
    //echo json_encode($datos);
?>
