<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    $cod_pro = $_POST['cod_pro'];
    $capacidad = $_POST['capacidad'];
 
    
    // PRUEBAS
    //$cod_pro = 1;
    //$capacidad = 1;
    
    //$query = $mysqli->query("CALL sp_BonifVenta('$cod_pro', '$capacidad')");
    $sql = "EXEC sp_MsfBonifVenta $cod_pro,$capacidad"; 
    //$datos = array();
    $stmt = $base_de_datos->prepare($sql); 

    $stmt->execute(); 

      while($resultado = $stmt->fetch(PDO::FETCH_NUM)) {
        $datos = $resultado;
    }
    /*

    while($resultado = $query->fetch_row()) {
        $datos = $resultado;
    }*/
    
    //echo json_encode(array("Precios" => $datos));
    echo json_encode($datos);
?>
