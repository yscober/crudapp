# ************************************************************
# Sequel Pro SQL dump
# Versión 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.5-10.1.37-MariaDB)
# Base de datos: app_ventas
# Tiempo de Generación: 2019-09-20 23:35:44 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Volcado de tabla cliente
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `COD_CLI` decimal(10,0) NOT NULL,
  `NOMBRE_CLIENTE` varchar(150) NOT NULL,
  `COD_USUARIO` decimal(10,0) NOT NULL,
  `DIRECCION` varchar(150) NOT NULL,
  PRIMARY KEY (`COD_CLI`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;

INSERT INTO `cliente` (`COD_CLI`, `NOMBRE_CLIENTE`, `COD_USUARIO`, `DIRECCION`)
VALUES
	(1,'CLIENTES VARIOS',1,'SU CASA'),
	(2,'SAMUEL CONTRERAS',1,'TRUJILLO'),
	(3,'GILMER OLIVO',2,'LIMA'),
	(4,'VALDEMAR',2,'TACNA');

/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla comercializacion
# ------------------------------------------------------------

DROP TABLE IF EXISTS `comercializacion`;

CREATE TABLE `comercializacion` (
  `COD_UNIDAD` varchar(4) NOT NULL,
  `COD_PRO` decimal(10,0) NOT NULL,
  `CAPACIDAD` decimal(5,0) NOT NULL,
  PRIMARY KEY (`COD_UNIDAD`,`COD_PRO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `comercializacion` WRITE;
/*!40000 ALTER TABLE `comercializacion` DISABLE KEYS */;

INSERT INTO `comercializacion` (`COD_UNIDAD`, `COD_PRO`, `CAPACIDAD`)
VALUES
	('CAJ',1,12),
	('CAJ',2,24),
	('UND',1,1),
	('UND',2,1),
	('UND',3,1);

/*!40000 ALTER TABLE `comercializacion` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla detalle_ventas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `detalle_ventas`;

CREATE TABLE `detalle_ventas` (
  `COD_DETVTA` int(11) NOT NULL AUTO_INCREMENT,
  `COD_VEN` int(11) NOT NULL,
  `COD_PRO` int(11) NOT NULL,
  `COD_UND` varchar(4) NOT NULL,
  `CANTIDAD` decimal(10,2) NOT NULL,
  `PRECIO` decimal(10,2) NOT NULL,
  `BONIF` char(1) DEFAULT NULL,
  PRIMARY KEY (`COD_DETVTA`),
  KEY `COD_PRO` (`COD_PRO`),
  KEY `COD_VEN` (`COD_VEN`),
  KEY `COD_UND` (`COD_UND`),
  CONSTRAINT `detalle_ventas_ibfk_1` FOREIGN KEY (`COD_PRO`) REFERENCES `producto` (`COD_PRO`),
  CONSTRAINT `detalle_ventas_ibfk_2` FOREIGN KEY (`COD_VEN`) REFERENCES `ventas` (`COD_VEN`),
  CONSTRAINT `detalle_ventas_ibfk_3` FOREIGN KEY (`COD_UND`) REFERENCES `unidad` (`COD_UND`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

LOCK TABLES `detalle_ventas` WRITE;
/*!40000 ALTER TABLE `detalle_ventas` DISABLE KEYS */;

INSERT INTO `detalle_ventas` (`COD_DETVTA`, `COD_VEN`, `COD_PRO`, `COD_UND`, `CANTIDAD`, `PRECIO`, `BONIF`)
VALUES
	(1,4,1,'CAJ',2.00,12.00,NULL);

/*!40000 ALTER TABLE `detalle_ventas` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla factor
# ------------------------------------------------------------

DROP TABLE IF EXISTS `factor`;

CREATE TABLE `factor` (
  `COD_PRO` int(11) NOT NULL,
  `KEY_UNIDAD` varchar(4) NOT NULL,
  `CAPACIDAD` decimal(10,2) NOT NULL,
  PRIMARY KEY (`COD_PRO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `factor` WRITE;
/*!40000 ALTER TABLE `factor` DISABLE KEYS */;

INSERT INTO `factor` (`COD_PRO`, `KEY_UNIDAD`, `CAPACIDAD`)
VALUES
	(1,'UND',12.00),
	(2,'UND',24.00);

/*!40000 ALTER TABLE `factor` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla producto
# ------------------------------------------------------------

DROP TABLE IF EXISTS `producto`;

CREATE TABLE `producto` (
  `COD_PRO` int(11) NOT NULL,
  `NOMBRE` varchar(150) DEFAULT NULL,
  `COD_UND` varchar(4) NOT NULL,
  `FLAT_IMPUESTO` char(1) NOT NULL,
  PRIMARY KEY (`COD_PRO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;

INSERT INTO `producto` (`COD_PRO`, `NOMBRE`, `COD_UND`, `FLAT_IMPUESTO`)
VALUES
	(1,'LAVAVAJILLA LIMON 1 KG','CAJ','S'),
	(2,'CHOCOLATE SOL DE CUSCO X 12 ','CAJ','S'),
	(3,'PERFUME TUINIES 12 ML','UND','S');

/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla stock
# ------------------------------------------------------------

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `COD_STOCK` int(11) NOT NULL AUTO_INCREMENT,
  `COD_PRO` int(11) NOT NULL,
  `STOCK_PROD` decimal(10,2) NOT NULL,
  `PRECIO1` decimal(10,2) DEFAULT NULL,
  `CALCULADO1` decimal(10,2) DEFAULT NULL,
  `PRECIO2` decimal(10,2) DEFAULT NULL,
  `CALCULADO2` decimal(10,2) DEFAULT NULL,
  `PRECIO3` decimal(10,2) DEFAULT NULL,
  `CALCULADO3` decimal(10,2) DEFAULT NULL,
  `PRECIO4` decimal(10,2) DEFAULT NULL,
  `CALCULADO4` decimal(10,2) DEFAULT NULL,
  `PRECIO5` decimal(10,2) DEFAULT NULL,
  `CALCULADO5` decimal(10,2) DEFAULT NULL,
  `PRECIO6` decimal(10,2) DEFAULT NULL,
  `CALCULADO6` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`COD_STOCK`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;

INSERT INTO `stock` (`COD_STOCK`, `COD_PRO`, `STOCK_PROD`, `PRECIO1`, `CALCULADO1`, `PRECIO2`, `CALCULADO2`, `PRECIO3`, `CALCULADO3`, `PRECIO4`, `CALCULADO4`, `PRECIO5`, `CALCULADO5`, `PRECIO6`, `CALCULADO6`)
VALUES
	(1,1,10.50,1.00,12.00,2.00,24.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00),
	(2,2,6.00,1.00,24.00,1.50,36.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla unidad
# ------------------------------------------------------------

DROP TABLE IF EXISTS `unidad`;

CREATE TABLE `unidad` (
  `COD_UND` varchar(4) NOT NULL,
  `UNIDAD` varchar(50) NOT NULL,
  `SUNAT` varchar(10) NOT NULL,
  PRIMARY KEY (`COD_UND`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `unidad` WRITE;
/*!40000 ALTER TABLE `unidad` DISABLE KEYS */;

INSERT INTO `unidad` (`COD_UND`, `UNIDAD`, `SUNAT`)
VALUES
	('BOL','BOLSA','BY'),
	('CAJ','CAJA','BX'),
	('UND','UNIDAD','NIU');

/*!40000 ALTER TABLE `unidad` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla usuarios
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `COD_USUARIO` int(11) NOT NULL,
  `NOMBRE_USU` varchar(50) NOT NULL,
  `CONTRASEÑA` varchar(20) NOT NULL,
  PRIMARY KEY (`COD_USUARIO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;

INSERT INTO `usuarios` (`COD_USUARIO`, `NOMBRE_USU`, `CONTRASEÑA`)
VALUES
	(1,'10','123'),
	(2,'20','123');

/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;


# Volcado de tabla ventas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ventas`;

CREATE TABLE `ventas` (
  `COD_VEN` int(11) NOT NULL AUTO_INCREMENT,
  `COD_CLI` decimal(10,0) NOT NULL,
  `COD_USUARIO` int(11) NOT NULL,
  `FECHA` datetime NOT NULL,
  `CONDICION` char(1) NOT NULL,
  `TOTAL` decimal(10,2) NOT NULL,
  `OBSERVACION` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`COD_VEN`),
  KEY `COD_CLI` (`COD_CLI`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`COD_CLI`) REFERENCES `cliente` (`COD_CLI`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;

INSERT INTO `ventas` (`COD_VEN`, `COD_CLI`, `COD_USUARIO`, `FECHA`, `CONDICION`, `TOTAL`, `OBSERVACION`)
VALUES
	(4,1,1,'2019-09-12 00:00:00','C',24.00,'CRED');

/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;



--
-- Dumping routines (PROCEDURE) for database 'app_ventas'
--
DELIMITER ;;

# Dump of PROCEDURE sp_PreciosVenta
# ------------------------------------------------------------

/*!50003 DROP PROCEDURE IF EXISTS `sp_PreciosVenta` */;;
/*!50003 SET SESSION SQL_MODE="NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `sp_PreciosVenta`(IN `codigo` INT, IN `capacidad` DECIMAL(10,0))
    NO SQL
SELECT  case when capacidad > 1 then s.CALCULADO1 else s.CALCULADO1 / f.capacidad end  , case when capacidad > 1 then s.CALCULADO1 else s.CALCULADO2 / f.capacidad end ,
 case when capacidad > 1 then s.CALCULADO1 else s.CALCULADO3 / f.capacidad end ,case when capacidad > 1 then s.CALCULADO1 else s.CALCULADO4 / f.capacidad end, 
 case when capacidad > 1 then s.CALCULADO1 else s.CALCULADO5 / f.capacidad end , case when capacidad > 1 then s.CALCULADO1 else s.CALCULADO6 /f.capacidad end 
 FROM factor f
 inner join producto p on p.COD_PRO = f.COD_PRO
 inner join stock s on s.COD_PRO = p.COD_PRO
 where p.COD_PRO = codigo */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;;
DELIMITER ;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
