<?php

    //require "conexion.php";
    require "AccesoSql.php";
    //$cod_pro = $_POST['cod_pro'];
    //$capacidad = $_POST['capacidad'];
    
    // PRUEBAS
    //$cod_pro = 1;
    //$capacidad = 1;
    
            $query = "SELECT  F.Calculado1 , F.Calculado2 , F.Calculado3 , F.Calculado4 , F.Calculado5 ,F.Calculado6 FROM PRESENTACION_ARTICULO P INNER JOIN FST_STOCK_ART F ON F.cod_art = P.KEY_PREART WHERE F.IdEmpresa = 1  and p.KEY_PREART = 3336";
           // $query = $mysqli->query($sql);
            $res =  sqlsrv_query($conn, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET ));

           $datos = array();
                 if (0 !== sqlsrv_num_rows($res))
                            {
                                while ($fila = sqlsrv_fetch_array($res)) 
                                {
                                    $datos[] = $fila ;
                                }
                                echo json_encode( $datos); 
                            }

                            /*
                              while($resultado = $query->fetch_row()) {
                                $datos = $resultado;
                                }

                                echo json_encode($datos);
                            */


?>
