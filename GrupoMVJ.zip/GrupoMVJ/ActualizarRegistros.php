<?php
require "conexionremoto.php";
require "conexion.php";
$sql 		= "DELETE FROM USUARIOS ";
$query 		= $mysqli01 ->query($sql);

        $sql01 		= "SELECT * FROM USUARIOS";
        $query01 	= $mysqli->query($sql01);

		
		if ($query01) {
			        
				while($row = $query01->fetch_assoc()) {    
				
				$COD_USUARIO 		= $row["COD_USUARIO"];
				$NOMBRE_USU			=$row['NOMBRE_USU'];
				$CONTRASENA			=$row['CONTRASENA'];
				echo $COD_USUARIO.''. $NOMBRE_USU.''. $CONTRASENA ."<br>";
				$sql_usuario 		= "INSERT INTO USUARIOS VALUES($COD_USUARIO , $NOMBRE_USU ,$CONTRASENA)";
				$query = $mysqli01 ->query($sql_usuario );
			}
			}
	
$sql_CleinteD 				= "DELETE FROM cliente ";
$query 						= $mysqli01 ->query($sql_CleinteD );	
			 $sql_CleinteC 	= "SELECT * FROM cliente";
			 $queryCleinte 	= $mysqli->query($sql_CleinteC);
			 
		if ($queryCleinte) {
			        
				while($row = $queryCleinte->fetch_assoc()) {    
				
				$COD_CLI 		= 	$row["COD_CLI"];
				$NOMBRE_CLIENTE	=	$row['NOMBRE_CLIENTE'];
				$COD_USUARIO	=	$row['COD_USUARIO'];
				$DIRECCION		=	$row['DIRECCION'];

			}
			}

?>
	
