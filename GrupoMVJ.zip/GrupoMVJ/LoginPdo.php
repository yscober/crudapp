<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";

    $nombre_usu = $_POST['nombre_usu'];
    $contrasena = $_POST['contrasena'];
    
    if(empty($nombre_usu) || empty($contrasena)) {
        echo "ERROR1";
    } else {
        $stmt = $base_de_datos->prepare("SELECT KEY_USU AS COD_USUARIO , NOMBRE_USU,CONTRASENA FROM USUARIOS WHERE NOMBRE_USU='$nombre_usu' AND CONTRASENA='$contrasena'");
            $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();
           
                         $data = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $data[] = $row;
                        }

        If (count($data) == 1) { 


                echo json_encode(array("Usuario" => $data));
        } else 
          {
                     echo "ERROR2";
           }



    }
    
?>
