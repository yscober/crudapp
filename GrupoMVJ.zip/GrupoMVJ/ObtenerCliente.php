<?php

    require "conexion.php";
    
    $cod_usuario = $_POST['cod_usuario'];
    $nombre_cliente = $_POST['nombre_cliente'];
    
    // PRUEBAS
    //$cod_usuario = "1";
    //$nombre_cliente = "clie";

    if ($cod_usuario == 1) {
        
          $sql = "SELECT COD_CLI,NOMBRE_CLIENTE,1 as COD_USUARIO,DIRECCION FROM cliente WHERE  NOMBRE_CLIENTE LIKE '%$nombre_cliente%' order by NOMBRE_CLIENTE LIMIT 15";
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Cliente" => $datos));

    }/* elseif ($cod_usuario == 45) { 
                /*  $sql = "SELECT COD_CLI,NOMBRE_CLIENTE,61 as COD_USUARIO,DIRECCION FROM cliente WHERE  NOMBRE_CLIENTE LIKE '%$nombre_cliente%' order by NOMBRE_CLIENTE LIMIT 15";
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Cliente" => $datos));

    }*/
    else 
    {
    
    $sql = "SELECT * FROM cliente WHERE COD_USUARIO='$cod_usuario' AND NOMBRE_CLIENTE LIKE '%$nombre_cliente%'  order by NOMBRE_CLIENTE LIMIT 15";
    $query = $mysqli->query($sql);
    $datos = array();
    
    while($resultado    = $query->fetch_assoc()) {
        $datos[]        = $resultado;
    }
    
    echo json_encode(array("Cliente" => $datos));
    }
?>
