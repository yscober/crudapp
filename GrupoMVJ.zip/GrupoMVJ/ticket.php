<?php
include "fpdf/fpdf.php";
//https://evilnapsis.com/2018/04/26/php-formato-de-ticket-basico-para-impresoras-de-tickets-con-fpdf/
//https://parzibyte.me/blog/2017/09/10/imprimir-ticket-en-impresora-termica-php/
//if($imp = printer_open('RICOH Aficio MP 2851 PCL 6 en caja-pc (2 redireccionado)')){
$pdf = new FPDF($orientation='P',$unit='mm', array(45,350));
$pdf->AddPage();
$pdf->SetFont('Arial','B',8);    //Letra Arial, negrita (Bold), tam. 20
$textypos = 5;
$pdf->setY(2);
$pdf->setX(2);
$pdf->Cell(5,$textypos,"MVJ INVERSIONES SA");
$pdf->SetFont('Arial','',5);    //Letra Arial, negrita (Bold), tam. 20
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'-------------------------------------------------------------------');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'CANT.  ARTICULO       PRECIO               TOTAL');

    include_once "AccesoSqlPdo.php";
    $cod_ven = 96 ; //$_POST['cod_ven'];
    $moneda  = 'S /' ; 
    
  $stmt = $base_de_datos->prepare("SELECT P.DESCRI_PREART AS NOMBRE , D.CANTID_DETVEN AS CT, D.KEY_UNIMED AS COD_UND ,  ISNULL(PV2,0) AS TOTAL FROM DETALLE_VENTA_MOVIL_DIRECTO D INNER JOIN PRESENTACION_ARTICULO P ON P.KEY_PREART = D.KEY_PREART  WHERE D.KEY_VEN = '$cod_ven'");

       $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();
         $datos = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $datos[] = $row;
                        }

      //  echo json_encode(array("Productos" => $datos));                  	

$total =0;
$off = $textypos+6;
/*$producto = array(
	"q"=>1,
	"name"=>"XXXXX",
	"price"=>100
);*/
$productos = array($datos);//($producto, $producto, $producto, $producto, $producto );
foreach($datos as $pro){ //foreach($productos as $pro){
$pdf->setX(2);
$pdf->Cell(5,$off,$pro["CT"]);
$pdf->setX(6);
$pdf->Cell(35,$off,  strtoupper(substr($pro["NOMBRE"], 0,12)) );
$pdf->setX(20);
$pdf->Cell(11,$off,  "".number_format($pro["TOTAL"],2,".",",") ,0,0,"R");
$pdf->setX(32);
$pdf->Cell(11,$off,  "".number_format($pro["CT"]*$pro["TOTAL"],2,".",",") ,0,0,"R");

$total += $pro["CT"]*$pro["TOTAL"];
$off+=6;
}
$textypos=$off+6;

$pdf->setX(2);
$pdf->Cell(5,$textypos,"TOTAL: " );
$pdf->setX(38);
$pdf->Cell(5,$textypos,"$moneda ".number_format($total,2,".",","),0,0,"R");

$pdf->setX(2);
$pdf->Cell(5,$textypos+6,'GRACIAS POR TU COMPRA ');

$pdf->output();
//print($pdf);
//}else{
  //  echo 'No se pudo conectar a la impresora.';
  //}
