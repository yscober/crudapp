<?php

    require "AccesoSql.php";
    
    $nombre = $_POST['nombre'];

    if (empty($nombre)) {
        
        echo "Error";
    } else 
    {
        //if ($cod_usuario == 1) {

            $query = "SELECT p.key_preart as COD_PRO, p.descri_preart as NOMBRE, p.key_unimed as COD_UND, p.exento_preart as FLAT_IMPUESTO, f.stock_articulo as STOCK_PROD FROM presentacion_articulo p inner JOIN FST_STOCK_ART f ON p.key_preart =f.COD_art WHERE p.descri_preart LIKE '%$nombre%' and f.idempresa = 1 and BLOQUEO_PREART <>'S' order by p.descri_preart ,f.stock_articulo desc";
           // $query = $mysqli->query($sql);
            $res =  sqlsrv_query($conn, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET ));

            $datos = array();
                 if (0 !== sqlsrv_num_rows($res))
                            {
                                while ($fila = sqlsrv_fetch_array($res)) 
                                {
                                    $datos[] = $fila;
                                }
                                echo json_encode(array("Productos" => $datos)); 
                            }

    }


?>
