<?php

    require "conexion.php";

    if($_SERVER['REQUEST_METHOD'] == 'GET') {
        
        if($_GET['tabla'] == 'usuarios') {
            $sql                = "SELECT * FROM usuarios";
            $query              = $mysqli->query($sql);
            $datos              = array();
            while($resultado    = $query->fetch_assoc()) {
                $datos[]        = $resultado;
            }

            echo json_encode($datos);
        } else if($_GET['tabla'] == 'cliente') {
            $sql                = "SELECT * FROM cliente";
            $query              = $mysqli->query($sql);
            $datos              = array();
            while($resultado    = $query->fetch_assoc()) {
                $datos[]        = $resultado;
            }

            echo json_encode($datos);
        } else if($_GET['tabla'] == 'comercializacion') {
            $sql                = "SELECT * FROM comercializacion";
            $query              = $mysqli->query($sql);
            $datos              = array();
            while($resultado    = $query->fetch_assoc()) {
                $datos[]        = $resultado;
            }
            echo json_encode($datos);
        } else if($_GET['tabla'] == 'factor') {
            $sql                 = "SELECT * FROM factor";
            $query               = $mysqli->query($sql);
            $datos               = array();
            while($resultado     = $query->fetch_assoc()) {
                $datos[]         = $resultado;
            }
            echo json_encode($datos);
        } else if($_GET['tabla'] == 'producto') {
            $sql        = "SELECT * FROM producto";
            $query      = $mysqli->query($sql);

            $datos              = array();
            while($resultado    = $query->fetch_assoc()) {
                $datos[]        = $resultado;
            }

            echo json_encode($datos);
        } else if($_GET['tabla'] == 'stock') {
            $sql                = "SELECT * FROM stock";
            $query              = $mysqli->query($sql);

            $datos              = array();
            while($resultado    = $query->fetch_assoc()) {
                $datos[]        = $resultado;
            }

            echo json_encode($datos);
        } else if($_GET['tabla'] == 'unidad') {
            $sql                = "SELECT * FROM unidad";
            $query              = $mysqli->query($sql);
            $datos              = array();
            while($resultado    = $query->fetch_assoc()) {
                $datos[]        = $resultado;
            }

            echo json_encode($datos);
        } 
    }

?>