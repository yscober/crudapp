<?php

    require "conexion.php";
    
    $nombre = $_POST['nombre'];
    
    // PRUEBAS
    //$nombre = "LAVA";
    if (empty($nombre)) {
        
        echo "Error";
    } else 
    {
        //echo "Bien";
            $sql = "SELECT producto.COD_PRO, producto.NOMBRE, producto.COD_UND, producto.FLAT_IMPUESTO, stock.STOCK_PROD FROM producto JOIN stock ON producto.COD_PRO=stock.COD_PRO WHERE producto.NOMBRE LIKE '%$nombre%' order by producto.NOMBRE ,stock.STOCK_PROD desc";
            $query = $mysqli->query($sql);
            
            $datos = array();
            
            while($resultado = $query->fetch_assoc()) {
                $datos[] = $resultado;
            } 
           echo json_encode(array("Productos" => $datos)); 
    }
    

    
    
    //echo json_encode($datos);
?>
