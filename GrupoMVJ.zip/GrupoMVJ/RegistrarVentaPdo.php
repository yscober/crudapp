<?php
Header('Content-type:text/html; charset=UTF-8');
   class Venta {
        public $cod_cli;
        public $cod_usuario;
        public $fecha;
        public $condicion;
        public $total;
        public $observacion;
        public $cod_doc;
        
        public function getCodCli() { return $this->cod_cli; }
        public function getCodUsuario() { return $this->cod_usuario; }
        public function getFecha() { return $this->fecha; }
        public function getCondicion() { return $this->condicion; }
        public function getTotal() { return $this->total; }
        public function getObservacion() { return $this->observacion; }
        public function getDocumento() { return $this->cod_doc; }
    }
    
    class Producto {
        public $cod_pro;
        public $nomProducto;
        public $cod_und;
        public $cantidad;
        public $precio;
        public $bonif;
        
        public function getCodPro() { return $this->cod_pro; }
        public function getNomProducto() { return $this->nomProducto; }
        public function getCodUnd() { return $this->cod_und; }
        public function getCantidad() { return $this->cantidad; }
        public function getPrecio() { return $this->precio; }
        public function getBonif() { return $this->bonif; }
    }

    $json = $_POST['json'];
    
    $array = json_decode($json, true);
    
    $venta = new Venta();
    foreach($array['Venta'] as $item) {
        $venta->cod_cli         = $item['cod_cli'];
        $venta->cod_usuario     = $item['cod_usuario'];
        $venta->fecha           = $item['fecha'];
        $venta->condicion       = $item['condicion'];
        $venta->total           = $item['total'];
        $venta->observacion     = $item['observacion'];
        $venta->cod_doc         = $item['cod_doc'];
    }
    
    $productos = array();
    foreach($array['Productos'] as $item) {
        $producto = new Producto();
        $producto->cod_pro          = $item['cod_pro'];
        $producto->nomProducto      = $item['nomProducto'];
        $producto->cod_und          = $item['cod_und'];
        $producto->cantidad         = $item['cantidad'];
        $producto->precio           = $item['precio'];
        $producto->bonif            = $item['bonif'];
        array_push($productos, $producto);
    }
    // Cargando Datos Generales
     $igv        = 18.00;
     $fPago      = 1;
     $dPlaso     = 3;
     $serie      = 1;
     $numero     = 0;
     $dsto       = 0;
     $pComision  = 'N';
     $xml        = '\.xml';
     $pdf        = '\.pdf';
     $FE         = '' ;

     //$hoy   = date("Y-m-d H:i:s"); 
     $hoy = (localtime(time(),true));

     $SerieLetra ='' ; 
     if ($venta->cod_doc == 5)   {
            $FE = '1' ; 
            $SerieLetra ='FF' ;   
     } elseif ($venta->cod_doc == 6) {
            $FE = '1' ;
            $SerieLetra ='BB' ; 
        } else {
            $FE = '' ;
            $SerieLetra ='' ;
        }
      

     $Empresa    = 1;
     $SubTotal   = ($venta->total / (( $igv +100 ) / 100)) ;
     $TotalIgv   = $venta->total - $SubTotal ;
        include_once "AccesoSqlPdo.php";


        $sentencia = $base_de_datos->prepare("INSERT INTO VENTAS_MOVIL_DIRECTO ( KEY_CLI , KEY_USU , KEY_VENDEDOR,FECHA_VEN ,ESTADO_VEN , OBSANULA_VEN , TOTALIMPORTE , BARRAS , TIPO_CP ,IGV_VEN ,FORMA_PAGO ,DIAS_PLAZO , SERIE , NUMERO ,DESC_VEN , PAGO_COMISION , UBICACION_XML , UBICACION_PDF , TOTALVVENTAOPEGRAVADAS , TOTALVVENTAOPEXONERADAS , TOTALVVENTAOPEGRATUITAS , TOTALDESCUENTOS , TOTALIGV , FLAG_FACTURA_ELECTRONICA , SERIE_LETRA , SERIE_LETRA_TAMANIO) values (?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?);");

        $resultado = $sentencia->execute([$venta->cod_cli, $venta->cod_usuario ,$venta->cod_usuario, $venta->fecha,'1', $venta->condicion, $venta->total ,$venta->observacion, $venta->cod_doc,$igv ,$fPago ,$dPlaso ,$serie ,$numero ,$dsto ,$pComision ,$xml ,$pdf ,$SubTotal ,0,0,0,$TotalIgv,$FE ,$SerieLetra ,0]); 

         $cod_ven = $base_de_datos->lastInsertId();
  

        foreach($productos as $item) 
        {
            $cod_ven    = $cod_ven;
            $cod_pro    = $item->cod_pro;
            $cod_und    = $item->cod_und;
            $cantidad   = $item->cantidad;
            $precio     = $item->precio;
            $bonif      = $item->bonif;
        $stmt = $base_de_datos->prepare("INSERT INTO DETALLE_VENTA_MOVIL_DIRECTO (KEY_VEN ,KEY_PREART , KEY_UNIMED , CANTID_DETVEN , PV2 , GRATIS_DETVEN ) VALUES(?,?,?,?,?,?)");
        $resultado1 = $stmt->execute([$cod_ven, $cod_pro, $cod_und , $cantidad , $precio, $bonif]);

        }

          if ($cod_ven > 0)   
          {
               echo "Registrado Correctamente $cod_ven ";  
           } else {
                $cod_ven = 0 ;
               echo "$venta->cod_doc "  ; 
            }
       
    
?>
