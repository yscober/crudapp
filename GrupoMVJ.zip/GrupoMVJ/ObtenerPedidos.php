<?php

    require "conexion.php";
    
    $cod_usuario = $_POST['cod_usuario'];
    
    // PRUEBAS
    //$cod_usuario = 1;
     if ($cod_usuario == 1) {

            $sql = "SELECT V.COD_VEN , CONCAT(CASE when V.OBSERVACION = 'AAA' then ':)  ' else '' end ,IFNULL(u.NOMBRE_USU,'00') , ' ',C.NOMBRE_CLIENTE  )as NOMBRE_CLIENTE , V.TOTAL  FROM ventas V INNER JOIN CLIENTE C ON C.COD_CLI = V.COD_CLI LEFT JOIN usuarios u on u.COD_USUARIO = V.COD_USUARIO WHERE convert(V.fecha ,date ) = CURDATE() ORDER BY  V.COD_VEN ,u.NOMBRE_USU ";
    //
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Pedidos" => $datos));


     } 
/*elseif ($cod_usuario == 5) {
   //code to be executed if first condition is false and this condition is true;
   include_once "AccesoSqlPdo.php";
       $stmt = $base_de_datos->prepare("SELECT  V.KEY_VEN as COD_VEN ,U.NOMBRE_USU +'  '+CL.NOMBRE_CLI +' '+  IsNull(V.SERIE_LETRA,'00') +'0'+CONVERT(VARCHAR(10),V.SERIE) +'-'+ CONVERT (varchar(8),V.NUMERO ) as NOMBRE_CLIENTE  ,MONTO_CPC  AS TOTAL FROM CUENTAS_POR_COBRAR C INNER JOIN VENTAS V ON V.KEY_VEN = C.KEY_VEN INNER JOIN CLIENTES CL ON CL.KEY_CLI = V.KEY_CLI LEFT JOIN USUARIOS U ON U.KEY_USU = V.KEY_VENDEDOR  WHERE MONTO_CPC > 0 AND SALDADO = 'N' order by U.NOMBRE_USU,CL.NOMBRE_CLI,V.NUMERO ");
             $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $datos[] = $row;
                        }
   
    echo json_encode(array("Pedidos" => $datos));


}
*/
     else 
    {
    
    $sql = "SELECT V.COD_VEN , CONCAT( CASE when V.OBSERVACION = 'AAA' then ':)  ' else '' end ,C.NOMBRE_CLIENTE) as NOMBRE_CLIENTE , V.TOTAL FROM ventas V INNER JOIN CLIENTE C ON C.COD_CLI = V.COD_CLI WHERE convert(V.fecha ,date ) = CURDATE() AND V.COD_USUARIO = '$cod_usuario'";
    // AND OBSERVACION <>'AAA'";
    //
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Pedidos" => $datos));
    //echo json_encode($datos);
     }
?>
