<?php
ini_set('max_execution_time', 900);
require "conexionSamuel.php";
include_once "AccesoSqlPdo.php";

  class Producto {
        public $cod_pro;
        public $nombre;
        public $cod_und;
        public $flat_impuesto;

        
        public function getCodPro() { return $this->cod_pro; }
        public function getNomProducto() { return $this->nombre; }
        public function getCodUnd() { return $this->cod_und; }
        public function getCantidad() { return $this->flat_impuesto; }

    }

      class Precio {
      	public $COD_STOCK;
        public $COD_PRO;
        public $STOCK_PROD;
        public $calculado1;
        public $calculado2;
        public $calculado3;
        public $calculado4;
        public $calculado5;
        public $calculado6;

        public function getCOD_STOCK1() { return $this->COD_STOCK; }
        public function getCOD_PRO() { return $this->COD_PRO; }
        public function getSTOCK_PROD() { return $this->STOCK_PROD; }       
        public function getcalculado1() { return $this->calculado1; }
        public function getcalculado2() { return $this->calculado2; }
        public function getcalculado3() { return $this->calculado3; }
        public function getcalculado4() { return $this->calculado4; }
        public function getcalculado5() { return $this->calculado5; }
        public function getcalculado6() { return $this->calculado6; }

    }



      class capacidad01 {
      	public $cod_pro;
        public $key_unidad;
        public $capacidad;

        public function getcod_pro() { return $this->cod_pro; }
        public function getkey_unidad() { return $this->key_unidad; }
        public function getcapacidad() { return $this->capacidad; }       

    }
          class comercial {
      	public $cod_pro;
        public $key_unidad;
        public $capacidad;

        public function getcod_pro() { return $this->cod_pro; }
        public function getkey_unidad() { return $this->key_unidad; }
        public function getcapacidad() { return $this->capacidad; }       

    }

          class unidades {
      	public $COD_UND;
        public $UNIDAD;
        public $SUNAT;

        public function getCOD_UND() { return $this->COD_UND; }
        public function getUNIDAD() { return $this->UNIDAD; }
        public function getSUNAT() { return $this->SUNAT; }       

    }

           class clientes {
      	public $cod_cli;
        public $nombre_cliente;
        public $cod_usuario;
        public $direccion;

        public function getcod_cli() { return $this->cod_cli; }
        public function getnombre_cliente() { return $this->nombre_cliente; }
        public function getcod_usuario() { return $this->cod_usuario; }   
        public function getdireccion() { return $this->direccion; }    

    }

    $sql = "DELETE FROM producto ";
	  $query = $mysqli ->query($sql);
	  $sql = "DELETE FROM stock ";
	  $query = $mysqli ->query($sql);
	  $sql = "DELETE FROM factor ";
	  $query = $mysqli ->query($sql);
	  $sql = "DELETE FROM comercializacion ";
	  $query = $mysqli ->query($sql);
	  $sql = "DELETE FROM unidad ";
	  $query = $mysqli ->query($sql);
    
     $sql = "DELETE FROM detalle_ventas ";
     $query = $mysqli ->query($sql);
     $sql = "DELETE FROM ventas ";
     $query = $mysqli ->query($sql);


  $stmt = $base_de_datos->prepare("select key_preart as cod_pro , dbo.LimpiarCaracteres (SubString(descri_preart,1,70)) as nombre , key_unimed as cod_und , exento_preart as flat_impuesto from presentacion_articulo p inner join fst_stock_art f on f.cod_art = p.key_preart 
where f.idempresa = 1 and  bloqueo_preart = 'N' order by key_preart");
               $stmt->setFetchMode(PDO::FETCH_ASSOC);
               $stmt->execute();

              $data = array();
                      while ($row   = $stmt->fetch()){
                            $data[] = $row;
                        }

             $json  = json_encode(array("Productos" => $data)); ;
             $array = json_decode($json, true);
             $productos = array();



    foreach($array['Productos'] as $item) {
        $producto = new Producto();
        $producto->cod_pro        = $item['cod_pro'];
        $producto->nombre         = $item['nombre'];
        $producto->cod_und        = $item['cod_und'];
        $producto->flat_impuesto  = $item['flat_impuesto'];
        array_push($productos, $producto);
    }
   
              $stmt = $mysqli->prepare("INSERT INTO producto (COD_PRO ,NOMBRE , COD_UND , FLAT_IMPUESTO ) VALUES(?,?,?,?)");
            $stmt->bind_param("ssss", $cod_pro, $nombre, $cod_und, $flat_impuesto);
  foreach($productos as $item) {
            $cod_pro          = $item->cod_pro;
            $nombre           = $item->nombre;
            $cod_und          = $item->cod_und;
            $flat_impuesto    = $item->flat_impuesto;

         $stmt->execute();

        }

      $stmt = $base_de_datos->prepare("select f.key_stock_art as COD_STOCK ,f.cod_art as COD_PRO ,f.stock_articulo as STOCK_PROD ,
convert(numeric(10,2),f.precio1) as precio1,convert(numeric(10,2),f.calculado1) as calculado1,
convert(numeric(10,2),f.precio2) as precio2,convert(numeric(10,2),f.calculado2) as calculado2,
convert(numeric(10,2),f.precio3) as precio3,convert(numeric(10,2),f.calculado3) as calculado3,
convert(numeric(10,2),f.precio4) as precio4,convert(numeric(10,2),f.calculado4) as calculado4,
convert(numeric(10,2),f.precio5) as precio5,convert(numeric(10,2),f.calculado5) as calculado5,
convert(numeric(10,2),f.precio6) as precio6,convert(numeric(10,2),f.calculado6) as calculado6 
from fst_stock_art f inner join presentacion_articulo p on p.key_preart = f.cod_art where f.IdEmpresa = 1 and p.bloqueo_preart = 'N'");

         $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();

               $data = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $data[] = $row;
                        }
             $json      = json_encode(array("Precios" => $data)); ;
             $array     = json_decode($json, true);
             $Precios   = array();  
                   
       foreach($array['Precios'] as $item) {
        $Precio = new Producto();
        $Precio->COD_STOCK  = $item['COD_STOCK'];
        $Precio->COD_PRO    = $item['COD_PRO'];
        $Precio->STOCK_PROD = $item['STOCK_PROD'];
        $Precio->calculado1 = $item['calculado1'];
        $Precio->calculado2 = $item['calculado2'];
        $Precio->calculado3 = $item['calculado3'];
        $Precio->calculado4 = $item['calculado4'];
        $Precio->calculado5 = $item['calculado5'];
        $Precio->calculado6 = $item['calculado6'];

        array_push($Precios, $Precio);
    		}  
    		
              $stmt = $mysqli->prepare("INSERT INTO stock (COD_STOCK , COD_PRO , STOCK_PROD ,  CALCULADO1 ,  CALCULADO2 ,  CALCULADO3 ,  CALCULADO4 ,  CALCULADO5 ,  CALCULADO6 ) VALUES(?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssssss", $COD_STOCK, $COD_PRO, $STOCK_PROD, $calculado1 , $calculado2 , $calculado3 , $calculado4 , $calculado5 , $calculado6);
    	foreach($Precios as $item) {
            $COD_STOCK  = $item->COD_STOCK;
            $COD_PRO 	  = $item->COD_PRO;
            $STOCK_PROD = $item->STOCK_PROD;
            $calculado1 = $item->calculado1;
            $calculado2 = $item->calculado2;
            $calculado3 = $item->calculado3;
            $calculado4 = $item->calculado4;
            $calculado5 = $item->calculado5;
            $calculado6 = $item->calculado6;

         $stmt->execute();

        }	
$stmt = $base_de_datos->prepare("select p.key_preart  as cod_pro , case when IsNull(s.key_unimed,'n')= 'n' Then p.key_unimed else s.key_unimed end as key_unidad , 
IsNull(s.cantidad,1) as capacidad  from presentacion_Articulo p 
left join SUB_UNIDADES S ON S.KEY_PREART = P.KEY_PREART");

         $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();

               $data = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $data[] = $row;
                        }
             $json  = json_encode(array("capac" => $data)); ;
             $array = json_decode($json, true);
             $capac = array(); 

        foreach($array['capac'] as $item) {
        $capacidad01 				       = 	new Producto();
        $capacidad01->cod_pro 	   = 	$item['cod_pro'];
        $capacidad01->key_unidad   = 	$item['key_unidad'];
        $capacidad01->capacidad 	 = 	$item['capacidad'];
        array_push($capac, $capacidad01);
    		}  
    		
    		 $stmt = $mysqli->prepare("INSERT INTO factor (COD_PRO , KEY_UNIDAD , CAPACIDAD ) VALUES(?,?,?)");
            $stmt->bind_param("sss", $cod_pro, $key_unidad, $capacidad );
    	foreach($capac as $item) {
            $cod_pro  		= 	$item->cod_pro;
            $key_unidad 	= 	$item->key_unidad;
            $capacidad 		= 	$item->capacidad;

         $stmt->execute();

        }	


$stmt = $base_de_datos->prepare("select key_unimed as key_unidad , key_preart as cod_pro , convert(int ,cantid_tipcom )as capacidad from tipo_comercializacion t 
inner join fst_stock_art s on s.cod_art = t.key_preart
where s.idempresa = 1 ");

         $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();

               $data = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $data[] = $row;
                        }
             $json  = json_encode(array("comer" => $data)); ;
             $array = json_decode($json, true);
             $comer = array(); 

        foreach($array['comer'] as $item) {
        $comercial 				       = 	new Producto();
        $comercial->cod_pro 	   = 	$item['cod_pro'];
        $comercial->key_unidad   = 	$item['key_unidad'];
        $comercial->capacidad 	 = 	$item['capacidad'];
        array_push($comer, $comercial);
    		}  
    		
    		 $stmt = $mysqli->prepare("INSERT INTO comercializacion (COD_PRO , COD_UNIDAD , CAPACIDAD ) VALUES(?,?,?)");
            $stmt->bind_param("sss", $cod_pro, $key_unidad, $capacidad );
    	foreach($comer as $item) {
            $cod_pro  		= 	$item->cod_pro;
            $key_unidad 	= 	$item->key_unidad;
            $capacidad 		= 	$item->capacidad;

         $stmt->execute();

        }	



   $stmt = $base_de_datos->prepare("select key_unimed as COD_UND,nombre_unimed as UNIDAD, ISNULL(sunat,'NIU') AS SUNAT from UNIDADES_MEDIDA");

         $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();

               $data = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $data[] = $row;
                        }
             $json  = json_encode(array("uni" => $data)); ;
             $array = json_decode($json, true);
             $uni   = array(); 

        foreach($array['uni'] as $item) {
        $unidades 				  = 	new Producto();
        $unidades->COD_UND 	= 	$item['COD_UND'];
        $unidades->UNIDAD   = 	$item['UNIDAD'];
        $unidades->SUNAT 	  = 	$item['SUNAT'];
        array_push($uni, $unidades);
    		}  
    		
    		 $stmt = $mysqli->prepare("INSERT INTO unidad (COD_UND , UNIDAD , SUNAT ) VALUES(?,?,?)");
            $stmt->bind_param("sss", $COD_UND, $UNIDAD, $SUNAT );
    	foreach($uni as $item) {
            $COD_UND  		= 	$item->COD_UND;
            $UNIDAD 		  = 	$item->UNIDAD;
            $SUNAT 			  = 	$item->SUNAT;

         $stmt->execute();

        }	

$stmt = $base_de_datos->prepare("select key_cli as cod_cli , 
case when  len(dbo.LimpiarCaracteresEspeciales(dbo.LimpiarCaracteres (SubString( IsNull(nombre_cli,''), 1 ,80)))) > 0 Then
dbo.LimpiarCaracteresEspeciales(dbo.LimpiarCaracteres (SubString( IsNull(nombre_cli,''), 1 ,80))) else 'CLI' end as nombre_cliente , 
key_vendor as cod_usuario ,
case when len(dbo.LimpiarCaracteresEspeciales(dbo.LimpiarCaracteres (SubString( IsNull(dir_cli,''), 1 ,80))))  > 0  then 
dbo.LimpiarCaracteresEspeciales(dbo.LimpiarCaracteres (SubString( IsNull(dir_cli,''), 1 ,80)))  else 'av' end as direccion 
from clientes where key_vendor in (9,44,45,46,47,49)  and   activo_cli = 'S'");

         $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();

               $data = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $data[] = $row;
                        }
             $json  = json_encode(array("cli" => $data)); ;
             $array = json_decode($json, true);
             $cli   = array(); 

        foreach($array['cli'] as $item) {
        $unidades 				          = 	new Producto();
        $unidades->cod_cli 	        = 	$item['cod_cli'];
        $unidades->nombre_cliente   = 	$item['nombre_cliente'];
        $unidades->cod_usuario 	    = 	$item['cod_usuario'];
        $unidades->direccion 	      = 	$item['direccion'];
        array_push($cli, $unidades);
    		}  
    		
    		 $stmt = $mysqli->prepare("INSERT INTO cliente (COD_CLI , NOMBRE_CLIENTE , COD_USUARIO , DIRECCION ) VALUES(?,?,?,?)");
            $stmt->bind_param("ssss", $cod_cli, $nombre_cliente, $cod_usuario , $direccion  );
    	foreach($cli as $item) {
            $cod_cli  				= 	$item->cod_cli;
            $nombre_cliente 	= 	$item->nombre_cliente;
            $cod_usuario 			= 	$item->cod_usuario;
            $direccion 				= 	$item->direccion;

         $stmt->execute();

        }

echo "Datos Actualizados Correctamente";
?>
	
