<?php

    require "conexion.php";
    
    $cod_ven = $_POST['cod_ven'];
    
    // PRUEBAS
    //$cod_ven = 50;
    
    $sql = "SELECT P.NOMBRE , CONVERT(D.CANTIDAD ,INT) AS CT, D.COD_UND , CONVERT((IFNULL(D.CANTIDAD ,0) * IFNULL(D.PRECIO ,0)),DECIMAL(8,2)) AS TOTAL FROM DETALLE_VENTAS D INNER JOIN PRODUCTO P ON P.COD_PRO = D.COD_PRO  WHERE D.COD_VEN = '$cod_ven'";
    
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Detalles" => $datos));
    //echo json_encode($datos);
?>
