 <?php
    
 error_reporting(0);
    require "conexion.php";

      $sql = "SELECT `COD_VEN`,`COD_CLI`,`COD_USUARIO`,`FECHA`,`CONDICION`,`TOTAL`,`OBSERVACION`,`cod_doc` FROM ventas where OBSERVACION <>'AAA'";
    
    $query = $mysqli->query($sql);

    


    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
       $sql1 = "SELECT COD_PRO , COD_UND , CANTIDAD , PRECIO , BONIF from detalle_ventas where COD_VEN = 3";
       $query1 = $mysqli->query($sql1);

       $datos1 = array();

       while($resultado1= $query1->fetch_assoc()) {
        $datos1[] = $resultado1;
		}
    }
    
    //echo json_encode(array("Detalles" => $datos));
    echo json_encode($datos);
    echo json_encode($datos1);

      ?>