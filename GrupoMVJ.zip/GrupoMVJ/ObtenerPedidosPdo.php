<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    $cod_usuario = $_POST['cod_usuario'];
    
    // PRUEBAS
    //$cod_usuario = 1;
    if ($cod_usuario == 1) 
    {
        $stmt = $base_de_datos->prepare("SELECT V.KEY_VEN AS COD_VEN , CASE WHEN FLAT_FACT = '1' then ':) ' else ' ' end  + U.NOMBRE_USU +' '+ C.NOMBRE_CLI AS NOMBRE_CLIENTE , V.TOTALIMPORTE AS TOTAL  FROM VENTAS_MOVIL_DIRECTO V INNER JOIN CLIENTES C ON C.KEY_CLI = V.KEY_CLI  INNER JOIN USUARIOS U ON U.KEY_USU = V.KEY_USU WHERE CONVERT(VARCHAR(10),V.FECHA_VEN,103) = CONVERT(VARCHAR(10), GETDATE(),103) ORDER BY U.NOMBRE_USU , V.KEY_VEN ") ;
                 $stmt->setFetchMode(PDO::FETCH_ASSOC);
                            // Ejecutamos
                            $stmt->execute();
                             // Mostramos los resultados
                            while ($row = $stmt->fetch()){
                                $datos[] = $row;
                            }
       echo json_encode(array("Pedidos" => $datos));
    }
    else
     {
        $stmt = $base_de_datos->prepare("SELECT V.KEY_VEN AS COD_VEN , CASE WHEN FLAT_FACT = '1' then ':) ' else ' ' end + C.NOMBRE_CLI AS NOMBRE_CLIENTE , V.TOTALIMPORTE AS TOTAL  FROM VENTAS_MOVIL_DIRECTO V INNER JOIN CLIENTES C ON C.KEY_CLI = V.KEY_CLI WHERE CONVERT(VARCHAR(10),V.FECHA_VEN,103) = CONVERT(VARCHAR(10), GETDATE(),103)  AND V.KEY_USU = '$cod_usuario'");
                 $stmt->setFetchMode(PDO::FETCH_ASSOC);
                            // Ejecutamos
                            $stmt->execute();
                             // Mostramos los resultados
                            while ($row = $stmt->fetch()){
                                $datos[] = $row;
                            }
       
        echo json_encode(array("Pedidos" => $datos));
    }
    //echo json_encode($datos);
?>
