<?php
    //serverName\instanceName, portNumber (por defecto es 1433)
    //$serverName = "192.168.1.2\\MSSQLSERVER, 1433"; 
    $serverName = "192.168.1.190\\MSSQLSERVER, 1433"; 
    $connectionInfo = array( "Database"=>"ERP_MVJ2018", "UID"=>"sa", "PWD"=>"Sistemas2016" , "CharacterSet" => "UTF-8");

    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    //mysqli_set_charset( $conn,"utf8");
    // ini_set('mssql.charset', 'UTF-8'); 
    //$connectionInfo = array( "Database"=>"AdventureWorks", "CharacterSet" => "UTF-8");
   // mssql_set_charset($conn ,'UTF-8');
    if( $conn ) 
    {
        //echo "Conexión establecida.<br />";
    }else
    {
        echo "Conexión no se pudo establecer.<br />";
        die( print_r( sqlsrv_errors(), true));
    }

