<?php

    require "conexion.php";
    
    $cod_pro = $_POST['cod_pro'];
    
    // PRUEBAS
    //$cod_pro = 1;
    
    $sql = "SELECT * FROM comercializacion WHERE COD_PRO='$cod_pro'";
    $query = $mysqli->query($sql);
    
    $datos = array();
    
    while($resultado = $query->fetch_assoc()) {
        $datos[] = $resultado;
    }
    
    echo json_encode(array("Comercializacion" => $datos));
    //echo json_encode($datos);
?>
