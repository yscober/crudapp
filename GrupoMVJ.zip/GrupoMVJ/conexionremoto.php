<?php
    
    // Variables de la conexion a la DB
    $mysqli01 = new mysqli("localhost","root","Sistemas2016","app_ventas01");
    
    // Comprobamos la conexion
    if($mysqli01->connect_errno) {
        die("Fallo la conexion");
    } else {
        //echo "Conexion exitosa";
    }
    
    ?>
