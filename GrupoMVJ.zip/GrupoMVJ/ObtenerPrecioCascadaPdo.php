<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    //$cod_pro = $_POST['cod_pro'];
    $cod_usuario = 1;
    $cod_pro = 7;
    $capacidad = 100;
    
    // PRUEBAS
    //$cod_pro = 2;
     $datos = array();
   // $stmt = $base_de_datos->prepare( "SELECT KEY_UNIMED AS COD_UNIDAD , KEY_PREART as COD_PRO , CANTID_TIPCOM AS CAPACIDAD  FROM TIPO_COMERCIALIZACION WHERE KEY_PREART='$cod_pro'");
    $sql = "sp_PrecioLista_MovilUsuarioPdo $cod_usuario,$cod_pro,$capacidad"; 
    $stmt = $base_de_datos->prepare($sql); 

     //$stmt->setFetchMode(PDO::FETCH_ASSOC);
        // Ejecutamos
        $stmt->execute();
         // Mostramos los resultados
        while ($row = $stmt->fetch()){
            $datos[] = $row;
        }
      echo json_encode(array("Precio" => $datos));
    //echo json_encode($datos);
?>
