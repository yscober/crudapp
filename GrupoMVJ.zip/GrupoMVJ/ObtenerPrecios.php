<?php

    require "conexion.php";
   // $cod_usuario    = $_POST['cod_usuario'];
    $cod_pro = $_POST['cod_pro'];
    $capacidad = $_POST['capacidad'];
    
    // PRUEBAS
    //$cod_pro = 1;
    //$capacidad = 1;
    
    $query = $mysqli->query("CALL sp_PreciosVenta('$cod_pro', '$capacidad')");
    $datos = array();
    
    while($resultado = $query->fetch_row()) {
        $datos = $resultado;
    }
    
    //echo json_encode(array("Precios" => $datos));
    echo json_encode($datos);
?>
