<?php
    
    // Variables de la conexion a la DB
    $mysqli = new mysqli("192.168.1.101","root","","app_ventas");
    
    // Comprobamos la conexion
    if($mysqli->connect_errno) {
        die("Fallo la conexion");
    } else {
        //echo "Conexion exitosa";
    }
/* $hostname ="192.168.1.101";
$usuario="root";
$contraseña = "";
$database = "app_ventas";
$utf  ="charset=utf8";
try {
$con = new PDO('mysql:host='.$hostname.';dbname='.$database, $usuario, $contraseña);
print "Conexión exitosa!";
}
catch (PDOException $e) {
print "¡Error!: " . $e->getMessage() . "
";
die();
}
$con =null;

*/


    
    ?>
