<?php

    require "AccesoSql.php";
    $cod_usuario = $_POST['cod_usuario'];
    $nombre = $_POST['nombre'];
    If  ($cod_usuario  == 69)
	{
            $query = "SELECT p.key_preart as COD_PRO, p.descri_preart as NOMBRE, p.key_unimed as COD_UND, p.exento_preart as FLAT_IMPUESTO, f.stock_articulo as STOCK_PROD FROM presentacion_articulo p inner JOIN FST_STOCK_ART f ON p.key_preart =f.COD_art inner join articulos_proveedor dl on dl.key_preart = p.key_preart  WHERE p.descri_preart LIKE '%$nombre%' and f.idempresa = 1 and dl.key_pro IN(274) and p.BLOQUEO_PREART <>'S' order by p.descri_preart ,f.stock_articulo desc";
            $res =  sqlsrv_query($conn, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET ));

            $datos = array();
                 if (0 !== sqlsrv_num_rows($res))
                            {
                                while ($fila = sqlsrv_fetch_array($res)) 
                                {
                                    $datos[] = $fila;
                                }
                                echo json_encode(array("Productos" => $datos)); 
                            }
    } else
    {

			if (empty($nombre)) 
			{
				echo "Error";
			} else 
			{
					$query = "SELECT p.key_preart as COD_PRO, p.descri_preart +' '+ IsNull(dbo.f_unidadequivalencia ( p.key_preart),'') as NOMBRE, p.key_unimed as COD_UND, p.exento_preart as FLAT_IMPUESTO, Convert(Decimal(10,2), f.stock_articulo) as STOCK_PROD FROM presentacion_articulo p inner JOIN FST_STOCK_ART f ON p.key_preart =f.COD_art WHERE p.descri_preart LIKE '%$nombre%' and f.idempresa = 1 and p.BLOQUEO_PREART <>'S'order by p.descri_preart ,f.stock_articulo desc";
					$res =  sqlsrv_query($conn, $query, array(), array("Scrollable" => SQLSRV_CURSOR_KEYSET ));

					$datos = array();
						 if (0 !== sqlsrv_num_rows($res))
									{
										while ($fila = sqlsrv_fetch_array($res)) 
										{
											$datos[] = $fila;
										}
										echo json_encode(array("Productos" => $datos)); 
									}

			}
	}

?>
