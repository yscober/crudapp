<?php
Header('Content-type:text/html; charset=UTF-8');
    class Venta {
        public $cod_cli;
        public $cod_usuario;
        public $fecha;
        public $condicion;
        public $total;
        public $observacion;
        public $cod_doc;
        
        public function getCodCli() { return $this->cod_cli; }
        public function getCodUsuario() { return $this->cod_usuario; }
        public function getFecha() { return $this->fecha; }
        public function getCondicion() { return $this->condicion; }
        public function getTotal() { return $this->total; }
        public function getObservacion() { return $this->observacion; }
        public function getDocumento() { return $this->cod_doc; }
    }
    
    class Producto {
        public $cod_pro;
        public $nomProducto;
        public $cod_und;
        public $cantidad;
        public $precio;
        public $bonif;
        
        public function getCodPro() { return $this->cod_pro; }
        public function getNomProducto() { return $this->nomProducto; }
        public function getCodUnd() { return $this->cod_und; }
        public function getCantidad() { return $this->cantidad; }
        public function getPrecio() { return $this->precio; }
        public function getBonif() { return $this->bonif; }
    }
    
    require "conexion.php";
    
    $json = $_POST['json'];
    
    $array = json_decode($json, true);
    
    $venta = new Venta();
    foreach($array['Venta']     as $item) {
        $venta->cod_cli         = $item['cod_cli'];
        $venta->cod_usuario     = $item['cod_usuario'];
        $venta->fecha           = $item['fecha'];
        $venta->condicion       = $item['condicion'];
        $venta->total           = $item['total'];
        $venta->observacion     = $item['observacion'];
        $venta->cod_doc         = $item['cod_doc'];
    }
    
    $productos = array();
    foreach($array['Productos'] as $item) {
        $producto                   = new Producto();
        $producto->cod_pro          = $item['cod_pro'];
        $producto->nomProducto      = $item['nomProducto'];
        $producto->cod_und          = $item['cod_und'];
        $producto->cantidad         = $item['cantidad'];
        $producto->precio           = $item['precio'];
        $producto->bonif            = $item['bonif'];
        array_push($productos, $producto);
    }
    $hoy = getdate();
    $venta->fecha  = str_pad($hoy['year'], 4, "0", STR_PAD_LEFT) .'-'.str_pad($hoy['mon'], 2, "0", STR_PAD_LEFT) .'-'.str_pad($hoy['mday'], 2, "0", STR_PAD_LEFT).' '.date($hoy['hours'],'00').':'.str_pad($hoy['minutes'], 2, "0", STR_PAD_LEFT).':'.str_pad($hoy['seconds'], 2, "0", STR_PAD_LEFT);
    
    $sql_ventas = "INSERT INTO ventas VALUES('', '$venta->cod_cli', '$venta->cod_usuario', '$venta->fecha', '$venta->condicion', '$venta->total', '$venta->observacion', '$venta->cod_doc')";
    
    if($query_ventas = $mysqli->query($sql_ventas) === TRUE) {
        //echo "Se registro en VENTAS";
        $cod_ven    = $mysqli->insert_id;
        
        $stmt       = $mysqli->prepare("INSERT INTO detalle_ventas (COD_VEN, COD_PRO, COD_UND, CANTIDAD, PRECIO, BONIF) VALUES(?,?,?,?,?,?)");
        $stmt->bind_param("ssssss", $cod_ven, $cod_pro, $cod_und, $cantidad, $precio, $bonif);
        
        foreach($productos as $item) {
            $cod_ven        = $cod_ven;
            $cod_pro        = $item->cod_pro;
            $cod_und        = $item->cod_und;
            $cantidad       = $item->cantidad;
            $precio         = $item->precio;
            $bonif          = $item->bonif;
            
            $stmt->execute();
        }
        
        echo "VENTA REGISTRADA";
        
    }
    
?>
