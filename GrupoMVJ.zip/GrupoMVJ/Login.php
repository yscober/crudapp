<?php

    require "conexion.php";
    
    $nombre_usu = $_POST['nombre_usu'];
    $contrasena = $_POST['contrasena'];
    
    // PRUEBAS
    //$nombre_usu = "10";
    //$contrasena = "123";
    
    if(empty($nombre_usu) || empty($contrasena)) {
        echo "ERROR1";
    } else {
        $sql = "SELECT * FROM usuarios WHERE NOMBRE_USU='$nombre_usu' AND CONTRASENA='$contrasena'";
        $query = $mysqli->query($sql);
        
        if($query->num_rows == 1) {
            $data = array();
            while($resultado = $query->fetch_assoc()) {
                $data[] = $resultado;
            }
            echo json_encode(array("Usuario" => $data));
        } else {
            echo "ERROR2";
        }
    }
    
?>
