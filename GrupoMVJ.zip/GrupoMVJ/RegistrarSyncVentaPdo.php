<?php
    
    error_reporting(0);
    
    require "conexion.php";

            $sql                = "SELECT * FROM ventas  where observacion ='AAA' order by COD_VEN DESC";
            $query              = $mysqli->query($sql);
            $datos              = array();
            while($item    = $query->fetch_assoc()) {
                $datos[]        = $item;
            }
                foreach ($datos as  $item) {
                   // print_r($item);/* Obtener el Array completo por cada fila devuelta de la consulta*/
                    //echo $value['cod'];/* Obtener un campo especifico del array */
                       // $venta = new Venta();
                        $venta->cod_ven         = $item['COD_VEN'];
                        $venta->cod_cli         = $item['COD_CLI'];
                        $venta->cod_usuario     = $item['COD_USUARIO'];
                        $venta->fecha           = $item['FECHA'];
                        $venta->condicion       = $item['CONDICION'];
                        $venta->total           = $item['TOTAL'];
                        $venta->observacion     = $item['OBSERVACION'];
                        $venta->cod_doc         = $item['CONT'];
                       // print_r($venta->cod_ven );
                   //     echo $venta->cod_ven  ;

                           $sqlDet  = "SELECT * FROM detalle_ventas  where cod_ven = $venta->cod_ven ";
                            $queryDet   = $mysqli->query($sqlDet);
                            $datosDet   = array();

                            while($item    = $queryDet->fetch_assoc()) {
                                $datosDet[]        = $item;
                            }

                        
                                    //echo json_encode($datosDet);

      $SerieLetra ='' ; 
     if ($venta->cod_doc == 5)   {
            $FE = '1' ; 
            $SerieLetra ='FF' ;   
     } elseif ($venta->cod_doc == 6) {
            $FE = '1' ;
            $SerieLetra ='BB' ; 
        } else {
            $FE = '' ;
            $SerieLetra ='' ;
        }
      

     $Empresa    = 1;
     $SubTotal   = ($venta->total / (( $igv +100 ) / 100)) ;
     $TotalIgv   = $venta->total - $SubTotal ;
        include_once "AccesoSqlPdo.php";


        $sentencia = $base_de_datos->prepare("INSERT INTO VENTAS_MOVIL_DIRECTO ( KEY_CLI , KEY_USU , KEY_VENDEDOR,FECHA_VEN ,ESTADO_VEN , OBSANULA_VEN , TOTALIMPORTE , BARRAS , TIPO_CP ,IGV_VEN ,FORMA_PAGO ,DIAS_PLAZO , SERIE , NUMERO ,DESC_VEN , PAGO_COMISION , UBICACION_XML , UBICACION_PDF , TOTALVVENTAOPEGRAVADAS , TOTALVVENTAOPEXONERADAS , TOTALVVENTAOPEGRATUITAS , TOTALDESCUENTOS , TOTALIGV , FLAG_FACTURA_ELECTRONICA , SERIE_LETRA , SERIE_LETRA_TAMANIO) values (?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?);");

        $resultado = $sentencia->execute([$venta->cod_cli, $venta->cod_usuario ,$venta->cod_usuario, $venta->fecha,'1', $venta->condicion, $venta->total ,$venta->observacion, $venta->cod_doc,$igv ,$fPago ,$dPlaso ,$serie ,$numero ,$dsto ,$pComision ,$xml ,$pdf ,$SubTotal ,0,0,0,$TotalIgv,$FE ,$SerieLetra ,0]); 

         $cod_ven = $base_de_datos->lastInsertId();
  

    
          foreach ($datosDet as  $item) {
            $producto->cod_pro          = $item['COD_PRO'];
            $producto->cod_und          = $item['COD_UND'];
            $producto->cantidad         = $item['CANTIDAD'];
            $producto->precio           = $item['PRECIO'];
            $producto->bonif            = $item['BONIF'];

            $stmt = $base_de_datos->prepare("INSERT INTO DETALLE_VENTA_MOVIL_DIRECTO (KEY_VEN ,KEY_PREART , KEY_UNIMED , CANTID_DETVEN , PV2 , GRATIS_DETVEN ) VALUES(?,?,?,?,?,?)");
            $resultado1 = $stmt->execute([$cod_ven, $producto->cod_pro , $producto->cod_und  , $producto->cantidad ,  $producto->precio , $producto->bonif]);
                                        
                                    }

            $sqlActualizar = "UPDATE ventas SET observacion ='AAA' WHERE COD_VEN=$venta->cod_ven";

            if ($mysqli->query($sqlActualizar) === TRUE) {

             //    $query              = $mysqli->query($sql);
              echo "Documentos Actualizados";
            } else {
              echo "Error" ;
            }
        /*  if ($cod_ven > 0)   {
           echo "Registrado Correctamente $cod_ven ";  
         } else {
            $cod_ven = 0 ;
           echo "$venta->cod_doc "  ; 
        }*/
//echo  $producto->cod_pro ;

                 }
?>