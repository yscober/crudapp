<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    $cod_usuario      = $_POST['cod_usuario'];
    $nombre_cliente   = $_POST['nombre_cliente'];

        class Validar {
        public $Estado;
        public $Mensaje;
        public $TipoUsuario ;

        public function getEstado() { return $this->Estado; }
        public function getMensaje() { return $this->Mensaje; }
        public function getTipoUsuario() { return $this->TipoUsuario; }
      }

		$datosVar = array();
		$stmtVar = $base_de_datos->prepare("select IsNull(FlagUsuarioMovil,'0') as Estado ,IsNull(MensajeError,'')  as Mensaje ,TIPO_USU as Tipo from USUARIOS where KEY_USU = $cod_usuario");
		// Especificamos el fetch mode antes de llamar a fetch()
        $stmtVar->setFetchMode(PDO::FETCH_ASSOC);
        // Ejecutamos
        $stmtVar->execute();
        while ($row = $stmtVar->fetch())
		{
          //$datosVar[] = $row;
          $Estado =   $row['Estado'];
          $Mensaje =  $row['Mensaje'];  
          $TipoUsuario = $row['Tipo']; 
        }
       // echo $TipoUsuario ;/*

if ($Estado == 1) 
	{
                    if($TipoUsuario == 6)
					{
                                       $datos = array();
                                 $stmt = $base_de_datos->prepare("select KEY_CLI AS COD_CLI , NOMBRE_CLI + ' | '+ ISNULL(DIR_CLI,'') + ' | 'AS NOMBRE_CLIENTE , $cod_usuario AS COD_USUARIO , ISNULL(DIR_CLI,'') as DIRECCION from CLIENTES  WHERE convert(varchar(10) ,KEY_CLI )+NOMBRE_CLI like '%$nombre_cliente%' and ACTIVO_CLI = 'S' order by NOMBRE_CLI ");
                                // Especificamos el fetch mode antes de llamar a fetch()
                                $stmt->setFetchMode(PDO::FETCH_ASSOC);
                                // Ejecutamos
                                $stmt->execute();
                                // Mostramos los resultados
                                while ($row = $stmt->fetch())
								{
                                    $datos[] = $row;
                                }
                                   echo json_encode(array("Cliente" => $datos));

                      
                    }
                      else
                    {


                            if (empty($nombre_cliente)) 
							{
                                
                                echo "Error";
                            } 
							else 
                            {

									if ($cod_usuario == 1) 
									{
										
										 $datos = array();
										 $stmt = $base_de_datos->prepare("select KEY_CLI AS COD_CLI , NOMBRE_CLI + ' | '+ DIR_CLI + ' | '+ CONVERT(VARCHAR(50),dbo.f_Auditor(KEY_CLI)) +'| Doc:' + dbo.f_Auditor00(KEY_CLI) AS NOMBRE_CLIENTE , KEY_VENDOR AS COD_USUARIO , DIR_CLI as DIRECCION from CLIENTES  WHERE convert(varchar(10) ,KEY_CLI )+NOMBRE_CLI like '%$nombre_cliente%' adn ACTIVO_CLI = 'S' order by NOMBRE_CLI ");
										// Especificamos el fetch mode antes de llamar a fetch()
										$stmt->setFetchMode(PDO::FETCH_ASSOC);
										// Ejecutamos
										$stmt->execute();
										// Mostramos los resultados
										while ($row = $stmt->fetch())
										{
											$datos[] = $row;
										}
										   echo json_encode(array("Cliente" => $datos));
									} 
									elseif ($cod_usuario == 5) 
									{
												 $datos = array();
										 $stmt = $base_de_datos->prepare("select KEY_CLI AS COD_CLI , NOMBRE_CLI + ' | '+ DIR_CLI + ' | '+ CONVERT(VARCHAR(50),dbo.f_Auditor(KEY_CLI)) +'| Doc:' + dbo.f_Auditor00(KEY_CLI) AS NOMBRE_CLIENTE , 5 AS COD_USUARIO , DIR_CLI as DIRECCION from CLIENTES  WHERE convert(varchar(10) ,KEY_CLI )+NOMBRE_CLI like '%$nombre_cliente%' and ACTIVO_CLI = 'S' order by NOMBRE_CLI  ");
										// Especificamos el fetch mode antes de llamar a fetch()
										$stmt->setFetchMode(PDO::FETCH_ASSOC);
										// Ejecutamos
										$stmt->execute();
										// Mostramos los resultados
										while ($row = $stmt->fetch())
										{
											$datos[] = $row;
										}
										   echo json_encode(array("Cliente" => $datos));

									} 
									elseif ($cod_usuario == 61) 
									{
										$datos = array();
										$stmt = $base_de_datos->prepare("select KEY_CLI AS COD_CLI , NOMBRE_CLI + ' | '+ DIR_CLI AS NOMBRE_CLIENTE , 61 AS COD_USUARIO , DIR_CLI as DIRECCION from CLIENTES  WHERE convert(varchar(10) ,KEY_CLI )+NOMBRE_CLI like '%$nombre_cliente%' and ACTIVO_CLI = 'S' order by NOMBRE_CLI ");
										// Especificamos el fetch mode antes de llamar a fetch()
										$stmt->setFetchMode(PDO::FETCH_ASSOC);
										// Ejecutamos
										$stmt->execute();
										// Mostramos los resultados
										while ($row = $stmt->fetch())
										{
											$datos[] = $row;
										}
										   echo json_encode(array("Cliente" => $datos));

									} 
									else 
									{
										$datos = array();
										$stmt = $base_de_datos->prepare("select KEY_CLI AS COD_CLI , NOMBRE_CLI + ' | '+ DIR_CLI AS NOMBRE_CLIENTE , KEY_VENDOR AS COD_USUARIO , DIR_CLI as DIRECCION from CLIENTES  WHERE KEY_VENDOR='$cod_usuario' AND convert(varchar(10) ,KEY_CLI )+NOMBRE_CLI like '%$nombre_cliente%' and ACTIVO_CLI = 'S' order by NOMBRE_CLI ");
										// Especificamos el fetch mode antes de llamar a fetch()
										$stmt->setFetchMode(PDO::FETCH_ASSOC);
										// Ejecutamos
										$stmt->execute();
										// Mostramos los resultados
										while ($row = $stmt->fetch())
										{
											$datos[] = $row;
										}
										   echo json_encode(array("Cliente" => $datos));
									}

                            }
                    }

    }
    else
    {
		$datos = array();
		$stmt = $base_de_datos->prepare("select TOP 1 0 AS COD_CLI , '$Mensaje'AS NOMBRE_CLIENTE , '$cod_usuario' AS COD_USUARIO , '' as DIRECCION from CLIENTES  WHERE  NOMBRE_CLI like '%$nombre_cliente%' order by NOMBRE_CLI ");
		// Especificamos el fetch mode antes de llamar a fetch()
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		// Ejecutamos
		$stmt->execute();
		// Mostramos los resultados
		while ($row = $stmt->fetch())
		{
		$datos[] = $row;
		}
		echo json_encode(array("Cliente" => $datos));
      

    }
?>
