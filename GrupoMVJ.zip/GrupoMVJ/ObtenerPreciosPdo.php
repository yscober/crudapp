<?php

 
    include_once "AccesoSqlPdo.php";
    $cod_usuario 	= $_POST['cod_usuario'];
    $cod_pro        = $_POST['cod_pro'];
    $capacidad      = $_POST['capacidad'];
    

//$sql = "EXEC sp_Precio_MovilPdo $cod_pro,$capacidad"; 

$sql = "EXEC sp_Precio_MovilUsuarioPdo $cod_usuario,$cod_pro,$capacidad"; 

$stmt = $base_de_datos->prepare($sql); 
//$stmt->bindParam( ':param' ,$cod_pro,$capacidad,PDO::PARAM_INT);
$stmt->execute(); 
//while( $rows = $stmt->fetch(PDO::FETCH_NUM)) { print_r($rows); }

   while($resultado = $stmt->fetch(PDO::FETCH_NUM)) {
        $datos = $resultado;
    }

    echo json_encode($datos);

?>
