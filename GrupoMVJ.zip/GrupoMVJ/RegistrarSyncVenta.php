<?php
    
    error_reporting(0);
    
    //require "conexion.php";
    require "conexionSamuel.php";
    //$ventaSync = $_POST['ventaSync'];
    
    // PRUEBAS
    $ventaSync = "2, 1, 2019-10-06 13:00:00, R, 72, CRED,5. 10, 1, 14, CJA, 5, 2, N; 2, 1, 2, CJA, 4, 3, N; 3, 1, 260, BLSA, 5, 10, N;7, 1, 2019-10-06 13:00:00, R, 72, CRED,5. 10, 1, 14, CJA, 5, 2, N; 2, 1, 2, CJA, 4, 3, N; 3, 1, 260, BLSA, 5, 10, N;";
    $venta          = explode(". ", $ventaSync);
    $arrayVenta     = explode(",", $venta[0]);
    $productos      = explode(";", $venta[1]);
    $cod_cli        = str_replace(" ", "", $arrayVenta[0]);
    $cod_usuario    = str_replace(" ", "", $arrayVenta[1]);
    $fecha          = $arrayVenta[2];
    $condicion      = str_replace(" ", "", $arrayVenta[3]);
    $total          = str_replace(" ", "", $arrayVenta[4]);
    $observacion    = str_replace(" ", "", $arrayVenta[5]);
    $documento      = str_replace(" ", "", $arrayVenta[6]);
    
    $sql_add_ven = "INSERT INTO ventas (cod_cli , cod_usuario , fecha , condicion , total , observacion ,cod_doc ) VALUES( '$cod_cli', '$cod_usuario', '$fecha', '$condicion', '$total', '$observacion' , '$documento')";
    
    if($query_ventas = $mysqli->query($sql_add_ven) === TRUE) {
        //echo "SE REGISTRO EN VENTAS<br><br>";
        $cod_ven = $mysqli->insert_id;
        //echo $cod_ven."<br><br>";
        
        for($i = 0 ; $i < sizeof($productos) ; $i++) {
            //echo $productos[$i]."<br>";
            $arrayDetVen = explode(",", $productos[$i]);
            
            $cod_pro    = str_replace(" ", "", $arrayDetVen[2]);
            $cod_und    = str_replace(" ", "", $arrayDetVen[3]);
            $cantidad   = str_replace(" ", "", $arrayDetVen[4]);
            $precio     = str_replace(" ", "", $arrayDetVen[5]);
            $bonif      = str_replace(" ", "", $arrayDetVen[6]);
            
            $sql_add_det_ven = "INSERT INTO detalle_ventas (COD_VEN, COD_PRO, COD_UND, CANTIDAD, PRECIO, BONIF) VALUES( '$cod_ven', '$cod_pro', '$cod_und', '$cantidad', '$precio', '$bonif')";
            
            $query_det_ven = $mysqli->query($sql_add_det_ven);
        }
        
        echo "OK";
    } else {
        echo "ERROR";
    }
    
?>
