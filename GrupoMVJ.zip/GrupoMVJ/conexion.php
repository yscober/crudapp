<?php
    
    // Variables de la conexion a la DB
	
    $mysqli = new mysqli("localhost","root","Sistemas2016","app_ventas");
    mysqli_set_charset($mysqli,"utf8");
    // Comprobamos la conexion
    if($mysqli->connect_errno) {
        die("Fallo la conexion");
    } else {
        //echo "Conexion exitosa";
    }
    
    ?>
