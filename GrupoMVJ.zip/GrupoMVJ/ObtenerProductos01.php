<?php

    require "conexion.php";
    
    //$nombre = $_POST['nombre'];
      $nombre  = "1"
    // PRUEBAS
    //$nombre = "LAVA";


      $variable = 0;
 
if (empty($variable)) {
    echo "\$variable está vacía o es 0";
} else {
    echo "\$variable no está vacía";
}


      //  if (empty($nombre)) 
        //empty($var);
       // {

               // $sql = "SELECT producto.COD_PRO, producto.NOMBRE, producto.COD_UND, producto.FLAT_IMPUESTO, stock.STOCK_PROD FROM producto JOIN stock ON producto.COD_PRO=stock.COD_PRO WHERE producto.NOMBRE LIKE '%virutex%' order by producto.NOMBRE ,stock.STOCK_PROD desc";
                //$result = $mysqli->query($sql);

                  //  $total_num_rows = $result->num_rows;
                    //$datos = array();
                    ////while($row = $result->fetch_array())
                    //while(($row = $result->fetch_assoc()) !== null)
                    //{
                      //  $datos[] = $row;
                        ////print_r($row);
                    //}
                     //echo json_encode(array("Productos" => $datos));
        //    echo "lola" ;
                        
        //}
        //elseIf
        //{
        //    echo "Error" ;
        //}

    


// while(($row = $result->fetch_assoc()) !== null){

   // $query = $mysqli->query($sql);

        //    while($row = $query12->fetch_assoc()) { 
     //       while($row = $result->fetch_array()) {   
       //         $COD_PRO        =   $row["COD_PRO"];
         //       $NOMBRE        =   $row['NOMBRE'];
           //     $COD_UND        =   $row['COD_UND'];
             //   $FLAT_IMPUESTO       =   $row["FLAT_IMPUESTO"];
               // $STOCK_PROD         =   $row['STOCK_PROD'];
               
    
                //echo $COD_PRO.''. $NOMBRE.''. $COD_UND .$FLAT_IMPUESTO.''. $STOCK_PROD .$STOCK_PROD."<br>";

            //}


    //echo "nombre: ".$rows[0]." ";
    //echo ($query) ;
   // $datos = array();
    
   // while($resultado = $query->fetch_assoc()) {
    //    $datos[] = $resultado;
    //}
    
    //echo json_encode(array("Productos" => $datos));
    //echo json_encode($datos);
?>
