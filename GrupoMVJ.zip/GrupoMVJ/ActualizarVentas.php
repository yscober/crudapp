<?php
require "conexionremoto.php";
require "conexion.php";

//$sql = "DELETE FROM cliente ";
//$query = $mysqli ->query($sql);

        $sql10 = "SELECT CONCAT( COD_USUARIO , COD_VEN , COD_CLI  ) AS COD_VEN  , COD_CLI , COD_USUARIO , FECHA , CONDICION ,TOTAL,OBSERVACION FROM ventas where OBSERVACION <> 'AAA'";
        $query10 = $mysqli->query($sql10);
		
		if ($query10) {
			        
				while($row 		= $query10->fetch_assoc()) {    
				$COD_VEN 		= 	$row["COD_VEN"];
				$COD_CLI		=	$row['COD_CLI'];
				$COD_USU		=	$row['COD_USUARIO'];
				$FECHA 			= 	$row["FECHA"];
				$COND			=	$row['CONDICION'];
				$TOTAL			=	$row['TOTAL'];
				$OBSER			=	$row['OBSERVACION'];				
				//echo $COD_VEN.''. $COD_CLI.''. $COD_USU .$FECHA.''. $COND .$TOTAL.''. $OBSER ."<br>";
				$sql11 = "INSERT INTO ventas (COD_VEN ,COD_CLI ,COD_USUARIO , FECHA , CONDICION , TOTAL , OBSERVACION ) VALUES('$COD_VEN','$COD_CLI','$COD_USU','$FECHA','$COND','$TOTAL' ,'$OBSER' )";
				$query11 = $mysqliremoto ->query($sql11 );
			}
			
			}

		$sql12 = "SELECT CONCAT( v.COD_USUARIO , v.COD_VEN , v.COD_CLI  ) AS COD_VEN, d.COD_PRO AS COD_PRO, d.COD_UND AS COD_UND , d.CANTIDAD AS  CANTIDAD, d.PRECIO AS PRECIO, d.BONIF AS BONIF FROM detalle_ventas d inner join ventas v on v.COD_VEN = d.COD_VEN   WHERE      ( v.OBSERVACION <> 'AAA' )";
		$query12 = $mysqli->query($sql12);	

		if ($query12) {
			        
				while($row = $query12->fetch_assoc()) {    
				$COD_VEN 		= 	$row["COD_VEN"];
				$COD_PRO		=	$row['COD_PRO'];
				$COD_UND		=	$row['COD_UND'];
				$CANTIDAD 		= 	$row["CANTIDAD"];
				$PRECIO			=	$row['PRECIO'];
				$BONIF			=	$row['BONIF'];
	
				//echo $COD_VEN.''. $COD_PRO.''. $COD_UND .$CANTIDAD.''. $PRECIO .$BONIF."<br>";
				$sql13 = "INSERT INTO detalle_ventas (COD_VEN ,COD_PRO ,COD_UND , CANTIDAD , PRECIO , BONIF ) VALUES('$COD_VEN','$COD_PRO','$COD_UND','$CANTIDAD','$PRECIO','$BONIF' )";
				$query13 = $mysqliremoto ->query($sql13 );
			}
			
				$sql14 = "UPDATE ventas set OBSERVACION ='AAA'  where OBSERVACION <> 'AAA'";
        		$query14 = $mysqli->query($sql14);
        		echo "VENTAS ENVIADAS";
			}

		        

?>
	
