<?php

    //require "AccesoSql.php";
    include_once "AccesoSqlPdo.php";
    $cod_usuario = $_POST['cod_usuario'];
    $nombre = $_POST['nombre'];

    if (empty($nombre)) {
        
        echo "Error";
    } else 
    {
            $stmt = $base_de_datos->prepare("SELECT p.key_preart as COD_PRO, p.descri_preart +' '+ IsNull(dbo.f_unidadequivalencia ( p.key_preart),'') as NOMBRE, p.key_unimed as COD_UND, p.exento_preart as FLAT_IMPUESTO, Convert(Decimal(10,2), f.stock_articulo) as STOCK_PROD FROM presentacion_articulo p inner JOIN FST_STOCK_ART f ON p.key_preart =f.COD_art WHERE p.descri_preart LIKE '%$nombre%' and f.idempresa = 1 and f.stock_articulo > 0 order by p.descri_preart ,f.stock_articulo desc");
           // $query = $mysqli->query($sql);
                     $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();
                         $datos = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $datos[] = $row;
                        }
                        echo json_encode(array("Productos" => $datos));     
    }


?>
