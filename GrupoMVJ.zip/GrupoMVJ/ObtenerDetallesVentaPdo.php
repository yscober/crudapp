<?php

    //require "conexion.php";
    include_once "AccesoSqlPdo.php";
    $cod_ven = $_POST['cod_ven'];
    
    // PRUEBAS
    //$cod_ven = 50;
    
    $stmt = $base_de_datos->prepare("SELECT P.DESCRI_PREART AS NOMBRE , D.CANTID_DETVEN AS CT, D.KEY_UNIMED AS COD_UND ,  ISNULL(PV2,0) AS TOTAL FROM DETALLE_VENTA_MOVIL_DIRECTO D INNER JOIN PRESENTACION_ARTICULO P ON P.KEY_PREART = D.KEY_PREART  WHERE D.KEY_VEN = '$cod_ven'");

       $stmt->setFetchMode(PDO::FETCH_ASSOC);
                        // Ejecutamos
                        $stmt->execute();
         $datos = array();
                         // Mostramos los resultados
                        while ($row = $stmt->fetch()){
                            $datos[] = $row;
                        }
        echo json_encode(array("Detalles" => $datos));
    //echo json_encode($datos);
?>
