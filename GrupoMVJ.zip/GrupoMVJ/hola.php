 <html>

<head>

//Pagina 1

</head>

<body>

<?php

//Se le da un valor a las variables

$variable1 = "Hola";

$variable2 = "como estas";

?>

//Link hacia la otra página

<a href="pagina2.php?variable1=<?php echo $variable1 ?>&variable2=<?php echo $variable2 ?>Ver la otra Pagina</a>

</body>

</html>